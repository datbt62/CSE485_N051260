<div class="footer-dark">
        <footer>
            <div class="container">
                <h4 align=center>Địa chỉ shop</h4>
                <br>
                <div class="row"><img src="assets/img/map.png" alt="" width=100%>
                </div>
                <br>
                
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Dịch vụ</h3>
                        <ul>
                            <li><a href="#">Thiết kế web</a></li>
                            <li><a href="#">Nhà phát triển</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Về chúng tôi</h3>
                        <ul>
                            <li><a href="#">Hướng dẫn</a></li>
                            <li><a href="#">Fanpage</a></li>
                            <li>Địa chỉ: 175 Tây Sơn, Đống Đa, Hà Nội </li>

                            
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>@ ToTo Shop</h3>
                        <p>Shop uy tín số 1 Hà Nội - Giao hàng toàn quốc - Phí vận chuyển thấp<br>
                        Bala.... Bala.....
                        </p>
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i
                                class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a
                            href="#"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                <p class="copyright">ToTo Shop © Coppyright </p>
            </div>
        </footer>
    </div>
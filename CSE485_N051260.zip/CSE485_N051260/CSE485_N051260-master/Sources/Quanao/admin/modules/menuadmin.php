<?php ?>
<div class="menuadmin nav nav-tabs sticky-top" style="background-color=black;">
<div class="col-md-2" align=center>
             <img src="assets/img/logofix.png" alt="" srcset=""></div>
<ul class="nav nav-pills ">
<li class="nav-item">
    <a class="nav-link"  aria-expanded="false" href="index.php?quanly=quanlytaikhoan&ac=them" style="color:#fcfeff;">Quản lý tài Khoản</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  aria-expanded="false" href="index.php?quanly=quanlysanpham&ac=them" style="color:#fcfeff;">Quản lý Sản phẩm</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  aria-expanded="false" href="index.php?quanly=quanlydonhang" style="color:#fcfeff;">Quản lý Đơn hàng</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  aria-expanded="false" href="index.php?quanly=quanlynhacungcap&ac=them" style="color:#fcfeff;">Quản lý Nhà cung cấp</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  aria-expanded="false" href="index.php?quanly=quanlyslide&ac=them" style="color:#fcfeff;">Quản lý slide tin tức</a>
  </li>
  
</ul>

</div>
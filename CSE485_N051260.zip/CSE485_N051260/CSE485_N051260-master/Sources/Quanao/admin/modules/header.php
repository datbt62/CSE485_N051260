<div class="headeradmin">
<div class="header-dark" style="background-color:black;height:80px;">
    <div class="col"><nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
        <div class="container">
            <a class="navbar-brand" href="../../Quanao/admin/">
                <img src="assets/img/logo.png" style="height:40px;">
            </a>
            
            <div class="collapse navbar-collapse" id="navcol-1">
                        
                    <div class="col-md-8">
                            <h4 align=center style="font-family: Florence, cursive;">TRANG QUẢN LÝ TOTO SHOP</h4>
                    </div>
                    <!-- <span class="navbar-text" style="color:black; padding:5px; margin:5px;">
                    <button type="button" class="btn btn-secondary" data-toggle="modal" data-target="#exampleModalCenter">Đổi mật khẩu</button>
                    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
		                        <form method="post" onsubmit="return false;" id="formChangePass">
                                <div class="modal-header">
                                 <h5 class="modal-title" id="exampleModalLongTitle">Đổi mật khẩu</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                           </div>
                           <div class="modal-body">
      
            <table cellpadding='5' cellspacing='5' text-color='black'>
                <tr>
                    <td>
                        Mật khẩu cũ :
                    </td>
                    <td>
                        <input type='text' name="username" size='40' id="old_pass" require="require"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Mật khẩu mới :
                    </td>
                    <td>
                        <input type='password' name="password" id="new_pass" size='40' require="require"/>
                    </td>
                </tr>
                <tr>
                    <td>
                       Nhập lại mật khẩu mới :
                    </td>
                    <td>
                        <input type='password' name="newpass" id="re_new_pass" size='40' require="require"/>
                    </td>
                </tr>
            </table>
                        </div>

        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Trở về</button>
        <button type="submit" id="submit_change_pass" class="btn btn-btn-secondary" name="change" id="button" value="Đổi">Đổi mật khẩu</button>
        </div>
			</form>
          </div>
          </div>
         </div>
         </span> -->
                        <form action="logout.php" class="dangxuat"><span class="navbar-text" style="color:black; padding:5px; margin:5px;">
                         <button class="btn btn-secondary">Đăng xuất</button>
                        </span>
                        </form>
                        </table>
            </div>
        </div>
        
    <nav>
    </div>
</div>
</div>


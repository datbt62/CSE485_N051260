<?php

$userName='root';
$passWord='';
$server='localhost';
$dbName='quanao';
//Kết nối
$cnn= mysqli_connect($server, $userName, $passWord, $dbName);
//Nếu kết nối lỗi thì thông báo và thoát


?>
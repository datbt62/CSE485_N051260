<div class="header">
<div class="header-dark" style="background-color:black;height:80px;">
    <div class="col"><nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/img/logo.png" style="height:40px;">
            </a>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1">
                <span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation">
                            <a class="nav-link" href="../Quanao">Trang chủ</a></li>
                            <li class="nav-item" role="presentation">
                            <a class="nav-link" href="#">Fanpage</a></li>
                            <li class="nav-item" role="presentation">
                            <a class="nav-link" href="#">Giới thiệu</a></li>
                        </ul>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group">
                            <label for="search-field">
                            <i class="fa fa-search"></i>
                            </label>
                            <input class="form-control search-field" type="search" name="search" id="search-field"></div>
                        </form>
                        <div class="shoppingcart">
                        <button class="btn btn-secondary" type="button" ><a href="index.php?page=listcart">
                        <img src="assets/img/_ionicons_svg_md-cart.svg" alt="" srcset="" height=30 width=30></a>
                        </button></div>
                        <span class="navbar-text" style="color:black; padding:5px; margin:5px;">
                        <button type="button" class="btn btn-secondary" data-toggle="modal" data-target="#exampleModalCenter">Đăng nhập</button>
                        
                        <?php include('dangnhap.php'); ?>
                        
                        </span>
                        
                        
            </div>
        </div>
        
    <nav>
    </div>
</div>
</div>



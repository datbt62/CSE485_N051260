<div class="content">

      
      
      
           <?PHP
		        $page=isset($_GET["page"])?$_GET["page"]:"";
		        if($page=='aothunnam'){
						$tensp='Áo thun';
						$tenloaisp='Nam';
						include('modules/chitietsp.php');			 
				}
				else 
				if($page=='aohoodienam'){
					$tensp='Áo hoodie';
					$tenloaisp='Nam';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='aosominam'){
					$tensp='Áo sơ mi';
					$tenloaisp='Nam';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='aothunnu'){
					$tensp='Áo thun';
					$tenloaisp='Nữ';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='aohoodienu'){
					$tensp='Áo hoodie';
					$tenloaisp='Nữ';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='aothunnam'){
					$tensp='Áo sơ mi';
					$tenloaisp='Nữ';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='aophaonam'){
					$tensp='Áo phao';
					$tenloaisp='Nam';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='aodanam'){
					$tensp='Áo dạ';
					$tenloaisp='Nam';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='aocadigannu'){
					$tensp='Áo cadigan';
					$tenloaisp='Nữ';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='quanjeansnam'){
					$tensp='Quần jeans';
					$tenloaisp='Nam';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='quankakinam'){
					$tensp='Quần kaki';
					$tenloaisp='Nam';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='quanjogger'){
					$tensp='Quần jogger';
					$tenloaisp='Nam';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='quanjeannu'){
					$tensp='Quần jeans';
					$tenloaisp='Nữ';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='chanvay'){
					$tensp='Chân váy';
					$tenloaisp='';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='damdutiec'){
					$tensp='Đầm dự tiệc';
					$tenloaisp='';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='quanaunu'){
					$tensp='Quần âu';
					$tenloaisp='Nữ';
					include('modules/chitietsp.php');			 
				}
				else 
				if($page=='damdichoi'){
					$tensp='Đầm đi chơi';
					$tenloaisp='';
					include('modules/chitietsp.php');			 
				}
				// else 
				// if($page=='aonam'){
				// 	$tensp='Áo%';
				// 	$tenloaisp='Nam';
				// 	include('modules/chitietsp.php');			 
				// }
				// else 
				// if($page=='aonu'){
				// 	$tensp='Áo%';
				// 	$tenloaisp='Nữ';
				// 	include('modules/chitietsp.php');			 
				// }
				else
				if($page=='listcart'){

					include('modules/giohang/listcart.php');
				}
				else
				if($page=='cart'){

					include('modules/giohang/cart.php');
				}
				else if($page=='checkout'){

					include('modules/giohang/checkout.php');
				}
				else
				if($page=='slide'){

					include('modules/slide/tintuc.php');
				}
		   ?>
            
      
        
    </div>    
    
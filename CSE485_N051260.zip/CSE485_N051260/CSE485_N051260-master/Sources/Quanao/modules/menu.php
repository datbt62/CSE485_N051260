<?php

?>

    <ul class="nav nav-tabs sticky-top">
        <div class="col-md-2" align=center>
             <img src="assets/img/logofix.png" alt="" srcset=""></div>
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="" style="color:#fcfeff;">Áo Nam</a>
                <div class="dropdown-menu" role="menu" >
                    <a class="dropdown-item" role="presentation" href="index.php?page=aothunnam" >Áo Thun</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=aohoodienam" >Áo hoodie</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=aosominam" >Áo sơ mi</a>
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="" style="color:#fcfeff;">Áo Nữ</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="index.php?page=aothunnu">Áo thun</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=aohoodienu">Áo hoodie</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=aosominu">Áo sơ mi</a>
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Áo Khoác</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="index.php?page=aophaonam">Áo phao Nam</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=aodanam">Áo dạ Nam</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=aocadigannu">Áo cadigan Nữ</a>
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Quần Nam</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="index.php?page=quanjeannam">Quần Jeans</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=quankakinam">Quần Kaki</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=quanjoggernam">Quần Jogger</a>
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Quần Nữ</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="index.php?page=chanvay">Chân váy</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=quanjeansnu">Quần Jeans</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=quanaunu">Quần Âu</a>
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Đầm</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="index.php?page=damdutiec">Đầm dự tiệc</a>
                    <a class="dropdown-item" role="presentation" href="index.php?page=đamichoi">Đầm đi chơi</a>
                    
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Áo Đôi</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="#">Hoodie đôi</a>
                    <a class="dropdown-item" role="presentation" href="#">Thun đôi</a>
                    <a class="dropdown-item" role="presentation" href="#">Sơ mi đôi</a>
                </div>
        </li>
    

    </ul>



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="col" align="center" type="padding=10px;"><h3> HOT ITEM</h3></div>
<div style="height:320px;">
        <div class="container" style="height:320px;">
            <div class="row" style="height:320px;">
                <div class="col-md-3">
                    <form style="height:320px;width:210px;">
                    <table>
                    <tr><img src="assets/img/SP/ao_khoac_doi_5__1__500x750.jpg" style="width:210px;height:250px;" class="sp"></tr>
                    
                    <tr>
                        <td><a href="#" style="width:92px;height:20px;">Thông Tin</a></td>
                        <td><button class="btn btn-primary" type="button">Đặt hàng</button></td>
                    </tr>
                    </table>
                </form>
                </div>
                <div class="col-md-3">
                    <form style="height:320px;width:210px;">
                    <table>
                    <tr><img src="assets/img/SP/ao_khoac_doi_11__1__500x750.jpg" style="width:210px;height:250px;" class="sp"></tr>
                    <tr>
                        <td><a href="#" style="width:92px;height:20px;" >Thông Tin</a></td>
                        <td><button class="btn btn-primary" type="button">Đặt hàng</button></td>
                    </tr>
                    </table>
                </form>
                </div>
                <div class="col-md-3">
                    <form style="height:320px;width:210px;">
                    <table>
                    <tr><img src="assets/img/SP/khoac_doi_8__1__500x750.jpg" style="width:210px;height:250px;" class="sp"></tr>
                    <tr>
                        <td><a href="#" style="width:92px;height:20px;">Thông Tin</a></td>
                        <td><button class="btn btn-primary" type="button">Đặt hàng</button></td>
                    </tr>
                    </table>
                </form>
                </div>
                <div class="col-md-3">
                    <form style="height:320px;width:210px;">
                    <table>
                    <tr><img src="assets/img/SP/khoac_doi_13__2__500x750.jpg" style="width:210px;height:250px;" class="sp"></tr>
                    <tr>
                        <td><a href="#" style="width:92px;height:20px;">Thông Tin</a></td>
                        <td><button class="btn btn-primary" type="button">Đặt hàng</button></td>
                    </tr>
                    </table>
                </form>
                </div>
                

                
            </div>
        </div>
</div>
<div style="height:320px;">
        <div class="container" style="height:320px;">
            <div class="row" style="height:320px;">
                <div class="col-md-3">
                    <form style="height:320px;width:210px;">
                    <table>
                    <tr><img src="assets/img/SP/ao_khoac_doi_5__1__500x750.jpg" style="width:210px;height:250px;" class="sp"></tr>
                    <tr>
                        <td><a href="#" style="width:92px;height:20px;">Thông Tin</a></td>
                        <td><button class="btn btn-primary" type="button">Đặt hàng</button></td>
                    </tr>
                    </table>
                </form>
                </div>
                <div class="col-md-3">
                    <form style="height:320px;width:210px;">
                    <table>
                    <tr><img src="assets/img/SP/ao_khoac_doi_5__1__500x750.jpg" style="width:210px;height:250px;" class="sp"></tr>
                    <tr>
                        <td><a href="#" style="width:92px;height:20px;">Thông Tin</a></td>
                        <td><button class="btn btn-primary" type="button">Đặt hàng</button></td>
                    </tr>
                    </table>
                </form>
                </div>
                <div class="col-md-3">
                    <form style="height:320px;width:210px;">
                    <table>
                    <tr><img src="assets/img/SP/ao_khoac_doi_5__1__500x750.jpg" style="width:210px;height:250px;" class="sp"></tr>
                    <tr>
                        <td><a href="#" style="width:92px;height:20px;">Thông Tin</a></td>
                        <td><button class="btn btn-primary" type="button">Đặt hàng</button></td>
                    </tr>
                    </table>
                </form>
                </div>
                <div class="col-md-3">
                    <form style="height:320px;width:210px;">
                    <table>
                    <tr><img src="assets/img/SP/ao_khoac_doi_5__1__500x750.jpg" style="width:210px;height:250px;" class="sp"></tr>
                    <tr>
                        <td><a href="#" style="width:92px;height:20px;">Thông Tin</a></td>
                        <td><button class="btn btn-primary" type="button">Đặt hàng</button></td>
                    </tr>
                    </table>
                </form>
                </div>
                

                
            </div>
        </div>
</div>
<?php 

?>


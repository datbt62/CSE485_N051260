
<div class="simple-slider">
    <div class="container-fulied">
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide" >
                    <img src="assets/img/slide/newfashionfemale.png" alt="" style="width: 1900px;">
                </div>
                <div class="swiper-slide" >
                    <img src="assets/img/slide/newfashionmale.png" alt="" style="width: 1900px;">
                </div>
                <div class="swiper-slide">
                    <img src="assets/img/slide/sb_1536895944_586.jpg" alt="" style="width: 1900px;">
                </div>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>
        </div>
</div>

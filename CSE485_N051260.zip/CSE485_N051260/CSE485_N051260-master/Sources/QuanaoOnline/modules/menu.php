
    <ul class="nav nav-tabs sticky-top">
    <div class="col-md-2" align=center> <img src="assets/img/logofix.png" alt="" srcset=""></div>
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Áo Nam</a>
                <div class="dropdown-menu" role="menu" >
                    <a class="dropdown-item" role="presentation" href="#" type="z-index=1000;coler=black;background-color:red;">Áo Thun</a>
                    <a class="dropdown-item" role="presentation" href="#" type="z-index=1000;coler=black;background-color:red;">Áo hoodie</a>
                    <a class="dropdown-item" role="presentation" href="#" type="z-index=1000;coler=black;background-color:red;">Áo sơ mi</a>
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Áo Nữ</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="#">Áo thun</a>
                    <a class="dropdown-item" role="presentation" href="#">Áo hoodie</a>
                    <a class="dropdown-item" role="presentation" href="#">Áo sơ mi</a>
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Áo Khoác</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="#">Áo phao</a>
                    <a class="dropdown-item" role="presentation" href="#">Áo dạ</a>
                    <a class="dropdown-item" role="presentation" href="#">Áo cadigan</a>
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Quần Nam</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="#">Quần Jeans</a>
                    <a class="dropdown-item" role="presentation" href="#">Quần Kaki</a>
                    <a class="dropdown-item" role="presentation" href="#">Quần Jogger</a>
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Quần Nữ</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="#">Chân váy</a>
                    <a class="dropdown-item" role="presentation" href="#">Quần Jeans</a>
                    <a class="dropdown-item" role="presentation" href="#">Quần Âu</a>
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Đầm</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="#">Đầm dự tiệc</a>
                    <a class="dropdown-item" role="presentation" href="#">Đầm đi chơi</a>
                    
                </div>
        </li>
    
    
        <li class="dropdown">
            <a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#" style="color:#fcfeff;">Áo Đôi</a>
                <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" role="presentation" href="#">Hoodie đôi</a>
                    <a class="dropdown-item" role="presentation" href="#">Thun đôi</a>
                    <a class="dropdown-item" role="presentation" href="#">Sơ mi đôi</a>
                </div>
        </li>
    

    </ul>


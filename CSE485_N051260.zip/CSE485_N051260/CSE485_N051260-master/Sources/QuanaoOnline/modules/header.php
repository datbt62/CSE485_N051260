<div class="header-dark" style="background-image:url(&quot;assets/img/hinh-nen-4k-dep-4_124943.jpg&quot;);height:80px;">
    <div class="col"><nav class="navbar navbar-dark navbar-expand-md navigation-clean-search">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="assets/img/logopx.png" style="height:40px;">
            </a>
            <button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1">
                <span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navcol-1">
                        <ul class="nav navbar-nav">
                            <li class="nav-item" role="presentation">
                            <a class="nav-link" href="index.php">Trang chủ</a></li>
                            <li class="nav-item" role="presentation">
                            <a class="nav-link" href="#">Fanpage</a></li>
                            <li class="nav-item" role="presentation">
                            <a class="nav-link" href="#">Giới thiệu</a></li>
                        </ul>
                        <form class="form-inline mr-auto" target="_self">
                            <div class="form-group">
                            <label for="search-field">
                            <i class="fa fa-search"></i>
                            </label>
                            <input class="form-control search-field" type="search" name="search" id="search-field"></div>
                        </form>
                        <button class="btn btn-primary" type="button" style="background-color:rgba(255,255,255,0.3);font-family:'Source Sans Pro', sans-serif;padding:4px;">Giỏ hàng</button>
                        <form class="dangnhap"><span class="navbar-text" style="color:rgba(0,0,0,0.1);">
                        <a href="" class="login" data-toggle="modal" data-target="#exampleModalCenter">Đăng nhập</a>
                        <?php include('thu.php'); ?>
                        </span>
                        </form>
            </div>
        </div>
        
    <nav>
    </div>
</div>


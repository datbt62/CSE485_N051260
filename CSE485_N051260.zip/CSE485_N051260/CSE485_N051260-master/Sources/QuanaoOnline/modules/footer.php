<div class="footer-dark">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Dịch vụ</h3>
                        <ul>
                            <li><a href="#">Thiết kế web</a></li>
                            <li><a href="#">Nhà phát triển</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Về chúng tôi</h3>
                        <ul>
                            <li><a href="#">Hướng dẫn</a></li>
                            <li><a href="#">Fanpage</a></li>
                            <li>Địa chỉ: 175 Tây Sơn, Đống Đa, Hà Nội </li>

                            
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>@ TD Shop</h3>
                        <p>Shop uy tín số 1 Hà Nội - Giao hàng toàn quốc - Phí vận chuyển thấp<br>
                        Bala.... Bala.....
                        </p>
                    </div>
                    <div class="col item social"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i
                                class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a
                            href="#"><i class="icon ion-social-instagram"></i></a></div>
                </div>
                <p class="copyright">TD Shop © 2017</p>
            </div>
        </footer>
    </div>